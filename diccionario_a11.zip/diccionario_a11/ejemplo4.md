|   Id | Nombre                  | Apellido_Paterno   | Apellido_Materno   | Sexo      | Puesto        |
|-----:|:------------------------|:-------------------|:-------------------|:----------|:--------------|
|   84 | ['Diego', 'Jose']       | Lopez              | Cruz               | Masculino | Gerente       |
|  176 | ['Yaritza', 'Ivonne']   | Hernandez          | Ramirez            | Femenino  | Mantenimiento |
|  112 | Octavio                 | Orci               | Figueroa           | Masculino | Operador      |
|   74 | Melissa                 | Hernandez          | Nevarez            | Femenino  | Mantenimiento |
|  161 | ['Antonio', 'Jose']     | Vega               | Martinez           | Masculino | Supervisor    |
|  270 | ['Fernando', 'Luis']    | Contreras          | Velarde            | Masculino | Supervisor    |
|  168 | ['Rebeca', 'Alicia']    | Medina             | Martinez           | Femenino  | Mantenimiento |
|  103 | ['Estefany', 'Melissa'] | Flores             | Castro             | Femenino  | Mantenimiento |
|   82 | Lenin                   | Gomez              | Cruz               | Masculino | Operador      |